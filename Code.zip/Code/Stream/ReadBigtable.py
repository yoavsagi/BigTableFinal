import numpy as np
import operator
from google.cloud import bigtable


def ConvertHexString(strNum):
    index = 0
    result = '' 
    while index < len(strNum):
        if strNum[index] != str("\\") and strNum[index] != str("x") and strNum[index] != str("'"):
            result = result + strNum[index]
        index = index + 1
    return int(result, 16)
def ArrayToInt(arrConv):
        value = 0
        for val in arrConv:
                value = value * 10 + val 
        return value
    
    
def ImportData(city):   
        print('Retrive data from table: New-York' + city)
        ResArr = {}
        client = bigtable.Client(project='summer-flux-199317' ,admin=True)
        instance = client.instance('mapreduce')
        table = instance.table(city)
        partial_rows = table.read_rows()
        partial_rows.consume_all()
        for row_key, row in partial_rows.rows.items():
                key = row_key.decode('utf-8')
                cell = row.cells['cf_count']['count'][0]
                if key.isalpha():
                        #print('Key:' + key + ' Cell:' + str(np.fromstring(str(cell.value), dtype='b')))
                        #print('Key:' + key + '  Cell:' + str(ArrayToInt(np.fromstring(str(cell.value), dtype='b'))))
                        ResArr[key] = ArrayToInt(np.fromstring(str(cell.value), dtype='b'))
        
        return ResArr
#=========================  L O G   D A D T A   O N  M O N G O  ========================================
import datetime
import pymongo
from pymongo import MongoClient

def GetCollectionByCity(city):
    if city == 'London':
        return db.London
    elif city == 'New-York':
        return db.NewYork
    elif city == 'Paris':
        return db.Paris
    elif city == 'San-Francisco':
        return db.SanFrancisco
    elif city == 'Mami':
        return db.Mami
    
def BuildPostArray(dicInsWord):
    postArry=[]
    
    for p in dicInsWord:
	postArry.append({"Word":p,"Count":dicInsWord[p]})
    
    return postArry

#Making a Connection with MongoClient
client = MongoClient('localhost', 27017)
db = client.WordCount

lstCities = ['New-York','Paris']
searchedWord = 'FIFA'

for city in lstCities:
    print('Read data from bigtable.  Table:' + city)
    arrByCity = ImportData(city)
    sortedArrByCity = sorted(arrByCity.items(), key=operator.itemgetter(1), reverse=True)
    
    #.Build Array of all destinct words
    print('Unification of words.  Table:' + city)
    CombWord = {}
    for item in sortedArrByCity:
	if not item[0] in CombWord:
            CombWord[item[0]] = item[1]
        else:
            CombWord[item[0]] = CombWord[item[0]] + item[1]
    
    #.Write Data to mongo database
    collection = GetCollectionByCity(city)
    print('Write to mogodb.  Collection:' + city)
    post_arr = BuildPostArray(CombWord)    
    collection.insert_many(post_arr)
    
    
    #index = 0
    #for item in sortedArrByCity:
    #    if (str(item[0]) != searchedWord and str(item[0]) != 'rt'):
    #            print('key: ' + str(item[0]) + '\t\t\tvalue: ' + str(item[1]))
    #    index = index + 1
    #    if index > 5:
    #        break







