#sudo apt-get install python-pip
#sudo pip install requests
#sudo pip install python-twitter

#sudo pip install -U numpy
#sudo pip install -U nltk
#import nltk
#nltk.download('stopwords')
#nltk.download('punkt')

#need to add to docker !!!!
#!pip install tweepy

# coding: utf8
import os
import twitter
import requests # use for sending request to google maps

#from google.cloud import storage

from datetime import datetime, timedelta   #used to get N last days

#for removing stop words
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

import string #remove punctations

import json
from google.cloud import bigtable

#For stwiter stream
from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream

import Queue
from threading import Thread #retrive from Q
import time

#------------------------------------------------------------------------------------------------------------------
#-------------------------------------------  Gogel Maps Retrive GeoCode Data  ----------------------------------------------
def GetJsonLocationFile(city):
    path = 'https://maps.googleapis.com/maps/api/geocode/json?&address={}&language=en'.format(city)
    req = requests.get(path)
    return req.json()


def ParseJesonFile(jFile):
     return [jFile["results"][0]["geometry"]["viewport"]["southwest"]["lng"],
             jFile["results"][0]["geometry"]["viewport"]["southwest"]["lat"],
             jFile["results"][0]["geometry"]["viewport"]["northeast"]["lng"],
             jFile["results"][0]["geometry"]["viewport"]["northeast"]["lat"]]


def BulidStrFromList(aList):
        newStr = ''
        for it in aList:
                newStr = newStr + ' ' + it
        return newStr

def RemoveMostCommonWord(text):
        stop_words = set(stopwords.words('english')) #from NLTK
        #move to lower and allow only ascii
        stripText = text.lower().encode('ascii',errors='ignore')
        stripText = stripText.translate(None, string.punctuation)
        stripText = stripText.translate(None,'?!/;":,')
        word_tokens = word_tokenize(stripText)
        filtered_sentence = [word for word in word_tokens if not word in stop_words]
        twit = filtered_sentence
        newText = BulidStrFromList(twit)
        return newText

def GetCityLocation(city):
	cityLocation = []
	try:
    		jFile = GetJsonLocationFile(city)
    		location = ParseJesonFile(jFile)
    		cityLocation.append((city, location))
	except:
    		print('Unable to create geocode array')
	return cityLocation;

#------------------------------------------------------------------------------------------------------------------
#-------------------------------------------  Twitt Strean Handler  ----------------------------------------------	
def InitTwitsStream(twiterAuth, cityLocation, searchTerm, table, columnsData):
	class StdOutListener(StreamListener):

    		def on_data(self, data):
        		data = json.loads(data)
			if 'text' in data:        			
				data = RemoveMostCommonWord(data['text'])
        			#print(data['text'])
				#text = data['text']
				#print(data)
				text = data	
				wordCount = TwittCountWord(text)
				#print('count:' +str(wordCount))
				#WriteRows2Table(table, columnsData,wordCount)		
				pushTwitWordtCount2Q(wordCount)
        		return True

    		def on_error(self, status):
        		print(status)
			return True

	#This handles Twitter authetification and the connection to Twitter Streaming API
	l = StdOutListener()
	auth = OAuthHandler(twiterAuth['consumer_key'], twiterAuth['consumer_secret'])
	auth.set_access_token(twiterAuth['access_token'], twiterAuth['access_token_secret'])
	stream = Stream(auth, l)
	stream.filter(track=searchTerm,
              languages=["en"],
              locations=[cityLocation[0][1][0],cityLocation[0][1][1],cityLocation[0][1][2],cityLocation[0][1][3]]) 

def TwittCountWord(twitt):
    wordDict = {} 
    splitArr = twitt.split(" ")

    for word in splitArr:
	if word != '':
        	if not word in wordDict:
             		wordDict[word] = 1
        	else:
            		wordDict[word] = wordDict[word] + 1    
    return wordDict

#----------------------------------work Q ----------------------------------
twitWordtCountQ = Queue.Queue()
num_fetch_threads = 2

def pushTwitWordtCount2Q(wordCount):
	#print('in push:' + str(wordCount))
	twitWordtCountQ.put(wordCount)	

def processTwitsJobs(i, q, writeRows2Table , metaData, table):
    #This is the worker thread function.
    while True:
        #print ('Looking for the next twit word count')
        wordCount = q.get()
	#print('in pop:' + str(wordCount))
	print("Q size: " + str(q.qsize()) )
	writeRows2Table(table, metaData,  wordCount)
        time.sleep(i + 2)
        #For each get() used to fetch a task, a subsequent call to task_done() tells the queue that the processing on the task is complete.
	q.task_done()
	

def InitTwit2DbsJobsThread(metaData, table):
	# Set up some threads to fetch the enclosures
	print('*** init reading twits jobs')
	for i in range(num_fetch_threads):
    		worker = Thread(target=processTwitsJobs, args=(i, twitWordtCountQ, WriteRows2Table, metaData, table))
    		worker.setDaemon(True)
    		worker.start()
#--------------------------------------

def createTable(projInstanceId ,bigQInstanceId, tableId, columnsMetaData, toCreate):
        client = bigtable.Client(project=projInstanceId, admin=True)
        instance = client.instance(bigQInstanceId)
        table = instance.table(tableId)
        if toCreate :
                print('Creating the {} table.'.format(tableId))
                table.create()
                for i, columnData in enumerate(columnsMetaData):
                        cf1 = table.column_family(columnsMetaData[i][COLUMN_FAMILIY_ID])
                        cf1.create()
        return table


def WriteRows2Table(table, columnsData, dataRows):
   print('Writing  to big tabel...')
   for key,value in dataRows.items():
                row_key = key
		#print('key: '+ key)
		#print('value:' + str(value))
                row = table.row(row_key)
                for j, columnData in enumerate(columnsData):
                        cf = columnData[COLUMN_FAMILIY_ID]
                        colId = columnData[COLUMN_ID]
                        #print('colId:' + colId + ' cf: ' + cf + ' row_key:' +row_key)
                        row.set_cell(
                               cf,
                               colId,
                               value)
                        #if colId == 'count':
                        #       row.increment_cell_value(cf, colId,value)
                        #else:
                        #       row.set_cell(
                        #       cf,
                        #       colId,
                        #       value)
                row.commit()
                print('word:'+ row_key + ' Count:' + str(value))


COLUMN_ID =0
COLUMN_FAMILIY_ID =1

#------------------------------------------------------------------


def getColumnsMetaData():
	columnId='count'.encode('utf-8')
        columnFamilyId='cf_count'
        column1 = [columnId,  columnFamilyId]

        columns = [column1]
        
        return columns

import pymongo
#import json
from pymongo import MongoClient
def getJob(ip):
	#Making a Connection with MongoClient
	client = MongoClient()
	#ip = '35.196.195.125'
	#ip = '10.142.0.3'
	client = MongoClient(ip, 27017)
	dbName = 'jobs_database'
	db = client[dbName]
	jobs = db.jobs
	jobRes = jobs.find_and_modify(
        	query={'status':'New'},
        	remove = True
	)
	return jobRes

def main():
	#should be retrived as a JOB from mongo
	#tableName = 'New-York'
	#searchWord = 'FIFA'
	ip = '10.142.0.8'
	job = getJob(ip)
	tableName = job['city']
	searchWord = job['searchTerm']
	
	#print(job_post['searchTerm'])        
   	#print(job_post['city'])

	bigTableInstanceId ='mapreduce'
        googleProjectName = 'smiling-theory-197620'
        tableId = tableName.encode('utf-8')
        toCreate = 1
	metaData = getColumnsMetaData()
        table = createTable(googleProjectName, bigTableInstanceId, tableId, metaData, toCreate)
	print('table create.')
	
	consumer_key='UwVOXDApV09uqO6qHqKd9jgOy'
	consumer_secret='5J7k7nkvKCLs8Mh9ss1UCMRAsoxzqKoX9Pp7YVc1tN7CNnOJfv'
	access_token_key='984172762896924672-gfFPRQp8ZLVoex9GHXrwqlRl8TFKbJ9'
	access_token_secret='4KA4hyJmqTNt3wxxboDI9OVnmXZ4a6qp7xdlbZ0BXCrl9'


	twiterAuth={'consumer_key': consumer_key , 'consumer_secret': consumer_secret, 'access_token':access_token_key, 'access_token_secret':access_token_secret }
	city = tableName
	cityLocation = GetCityLocation(city)	
	searchTerm = [searchWord]
	
	InitTwit2DbsJobsThread(metaData, table)

	InitTwitsStream(twiterAuth, cityLocation, searchTerm, table, metaData)
        



main()

