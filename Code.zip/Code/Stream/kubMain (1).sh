export PROJECT_ID="$(gcloud config get-value project -q)"

echo ${PROJECT_ID}
CLUSTER_NAME='twitter-cluster'
echo "${CLUSTER_NAME}"
IMAGE_NAME='twitter'
echo $IMAGE_NAME
CONTAINER_NAME='twitter'
echo $CONTAINER_NAME 

echo 'Image list in gcloud:'
sudo gcloud container images list --repository=gcr.io/${PROJECT_ID}

echo ''
#read -p "Press any key to create the cluster..."
echo "Do you wish to create the cluster?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) gcloud container clusters create "${CLUSTER_NAME}" --num-nodes=2 --disk-size=10 --zone='europe-west2' --scopes="https://www.googleapis.com/auth/bigtable.admin.table,https://www.googleapis.com/auth/bigtable.data" ; break;;
        No ) break;;
    esac
done

echo "Do you wish to deploy the image the cluster?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) kubectl run ${CONTAINER_NAME} --image=gcr.io/${PROJECT_ID}/${IMAGE_NAME}:v2 --port 8080 ; break;;
        No ) break;;
    esac
done

echo "pods:"
kubectl get pods

echo "To export ports:"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) kubectl expose deployment ${CONTAINER_NAME} --type=LoadBalancer --port 80 --target-port 8080 ;
              kubectl get service;  break;;
        No ) break;;
    esac
done

echo "replicate the image"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) kubectl scale deployment ${CONTAINER_NAME} --replicas=3 ;
	      kubectl get deployment ${CONTAINER_NAME};
	      kubectl get pods;
 	      break;;
        No ) break;;
    esac
done


