import pymongo
import json, ast
import operator

from pymongo import MongoClient

cities = ['NewYork','Paris']


def GetCollectionByCity(city):
    if city == 'London':
        return db.London
    elif city == 'NewYork':
        return db.NewYork
    elif city == 'Paris':
        return db.Paris
    elif city == 'San-Francisco':
        return db.SanFrancisco
    elif city == 'Mami':
        return db.Mami
    
    
def GetSortTwittByCity(city):
    dicWords = {}
    collection = GetCollectionByCity(city)
   
    for post in collection.find({},{'_id':0,'Word':1,'Count':1}).sort([('Count', pymongo.DESCENDING)]):
        post=ast.literal_eval(json.dumps(post))
        if 'Word' in post:
                dicWords[post['Word']] = post['Count']
    dicWords = sorted(dicWords.items(), key=operator.itemgetter(1),reverse=False)
    return dicWords


def BuildCityContainer():
    cityContainer = {}
    for c in cities:
        cityContainer[c] = dict(GetSortTwittByCity(c))
    
    return cityContainer


def GetWordInAllCitys(cC):
    comboList = []
    for word in cC['Paris']:
    	if word in cC['Paris'] and word in cC['NewYork']:
            comboList.append(word)
    
    return comboList

def GetMaxShowCorssCities(cC):
    
    maxWord = max(cC[cities[0]].keys(), key=(lambda k: cC[cities[0]][k]))
    maxValue = cC[cities[0]][maxWord]
    maxCity = cities[0]

    for city in cities:
        rValue = max(cC[city].keys(), key=(lambda k: cC[city][k]))
        rWord = cC[cities[0]]
        print(city + ' - Word:' + rValue + '  Show:' + str(cC[city][rValue]))
        if cC[city][rValue] > maxValue:
            maxValue = cC[city][rValue]           
            maxWord = rValue
	    maxCity = city

    print('\nAnd The Winner Is - Word:' + maxWord + '  Show:' + str(maxValue))
    
    
def GetDistinctWords(cC):
    
    lstWords = []
    
    #.Run on all cities
    for city in cities:
        
        #.For each word in the citiy
        for word in cC[city]:
            flag = 0
            #.Go over all cities
            for inCity in cities:
                
                #. If it's the same citiy or the word is in different citiy => go to next word
                if inCity != city:
			if word in cC[inCity]:
		    		flag = 1
	    if flag == 0:
	        lstWords.append(word)         
        
    return lstWords        
        
            
#___________________________________  M A I N  ___________________________________________________
client = MongoClient('localhost', 27017)
db = client.WordCount
cityContainer = BuildCityContainer()

#. Show words that are in all cities
print('\n________________________________________________________________________________________')
print('Show words that are in all cities:')
comboL = GetWordInAllCitys(cityContainer)
for word in comboL:
     print(word)

print('\n\n________________________________________________________________________________________')
print('Show max appearances of a word across all cities:')
GetMaxShowCorssCities(cityContainer)


print('\n________________________________________________________________________________________')
print('Show words that are one in distinct cities:')
comboL = GetDistinctWords(cityContainer)
for word in comboL:
     print(word)



