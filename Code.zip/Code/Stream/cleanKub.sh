export PROJECT_ID="$(gcloud config get-value project -q)"
echo ${PROJECT_ID}
CLUSTER_NAME='twitter-cluster'
echo "${CLUSTER_NAME}"
IMAGE_NAME='twitter'
echo $IMAGE_NAME
CONTAINER_NAME='twitter'
echo $CONTAINER_NAME 


echo "Do you wish to deallocate the Cloud Load Balancer?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) kubectl delete service  ${CONTAINER_NAME} ; break;;
        No ) break;;
    esac
done

while true; do
    read -p "wait for LB to finish?[y/n]" yn
    case $yn in
        [Yy]* ) gcloud compute forwarding-rules list;; 
        [Nn]* ) break;;
        * ) echo "Please answer yes or no.";;
    esac
done


echo "Do you wish to delete the cluster?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) gcloud container clusters delete  ${CLUSTER_NAME} ;
	      gcloud compute instances list; 
		break;;
        No ) break;;
    esac
done


