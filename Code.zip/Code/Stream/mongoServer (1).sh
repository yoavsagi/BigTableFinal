#gcloud compute firewall-rules create default-allow-mongo \
#     --allow tcp:27017 \
#     --source-ranges 0.0.0.0/0 \
#     --target-tags mongodb \
#     --description "Allow mongodb access to all IPs"

#gcloud compute instances add-tags example-instance --tags tag-1,tag-2
#sudo service mongod restart
#sudo service mongodb stop
sudo service mongod start
sudo lsof -iTCP -sTCP:LISTEN | grep mongo
sudo service mongod status
#mongo --host 35.196.195.125:27017 --verbose
mongo --host 10.142.0.3:27017 --verbose
#mongo --host 35.196.195.125:27017
#mongo --host 127.0.0.1:27017

