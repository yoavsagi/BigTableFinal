#sudo python -m pip install pymongo

import datetime

import pymongo

from pymongo import MongoClient


#Making a Connection with MongoClient
client = MongoClient()
client = MongoClient('localhost', 27017)
#client = MongoClient('mongodb://localhost:27017/')

dbjobs = client.jobs_database
jobs = dbjobs.jobs

job_posts = [{"city":"paris", 
		"searchTerm": "FiFA",
		"status": "New"},
		{"city": "California",
               "searchTerm": "FiFA",
               "status": "New"},
              {"city": "New-York",
 		"searchTerm": "FiFA",
               "status": "New"}]
jobs_results = jobs.insert_many(job_posts)


#the posts collection has actually been created on the server. 
#We can verify this by listing all of the collections in our database
docs=dbjobs.collection_names(include_system_collections=False)
print(docs)


#Querying for More Than One Document
for job_post in jobs.find():
   print(job_post)

#for job_post in job_posts.find({"author": "Mike"}):
#   print(job_post)


#counting
print('count of jobs' + str(jobs.count()))

#Range Queries
#d = datetime.datetime(2009, 11, 12, 12)
#for post in posts.find({"date": {"$lt": d}}).sort("author"):
#   print(post)
