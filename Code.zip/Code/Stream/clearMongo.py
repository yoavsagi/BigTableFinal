import pymongo
import json
from pymongo import MongoClient
#Making a Connection with MongoClient
client = MongoClient()
client = MongoClient('localhost', 27017)
#client = MongoClient('mongodb://localhost:27017/')
dbName = 'test_database'
db = client[dbName]
client.drop_database(dbName)
posts = db.posts
print('count of posts: ' + str(posts.count()))
