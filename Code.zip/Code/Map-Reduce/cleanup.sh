echo "clean local folders..."
rm -r twitsDirectory/*.txt
rm  -r outputData/*.txt

#read -p "Press any key to create the cluster..."
echo "Do you wish to delete the cluster?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) 	cd /home/yoavs2/cloud-bigtable-examples/java/dataproc-wordcount
		./cluster.sh delete firstcluster ; break;; 
        No ) break;;
    esac
done

read -p "Press any key to clean the stroage backet with the twits..."
gsutil rm gs://smiling-theory-197620_map_reduce/twitsDirectory/*

