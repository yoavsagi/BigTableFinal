#!/usr/bin/env bash
tar -czf flask_hbase.tar.gz third_party  provision.sh client.py flask_thrift.py requirements.txt curl_examples.sh test.py
