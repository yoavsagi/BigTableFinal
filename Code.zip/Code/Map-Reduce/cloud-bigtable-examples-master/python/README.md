![status: inactive](https://img.shields.io/badge/status-inactive-red.svg)

The Google Cloud Bigtable Python samples have moved. This directory is no
longer actively developed or maintained.

For new work on this check out the
[Bigtable
samples](https://github.com/GoogleCloudPlatform/python-docs-samples/tree/master/bigtable)
in the Google Cloud Platform Python samples repository.
