The contents of this directory were taken from Apache HBase 1.2.1. 
The changed / added lines are marked by the tag 'LV3'.
