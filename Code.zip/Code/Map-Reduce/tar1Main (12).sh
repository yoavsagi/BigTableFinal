


export basePath=/home/yoavs2 
export mapreduceCodePath=/home/yoavs2/cloud-bigtable-examples/java/dataproc-wordcount
#echo "$mapreduceCodePath"
export  location=$(pwd)
#echo "$location"

#sudo apt-get install google-cloud-sdk-cbt
# project id
echo project = smiling-theory-197620 > ~/.cbtrc
#big table id
echo instance = mapreduce >> ~/.cbtrc

# we have big files instead
#echo "starting twits downlod"
#python tar1  

echo "Do you wish to run python code to rerive twits?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) python tar1   ; break;;
        No ) break;;
    esac
done

#read -p "Press any key to create the cluster..."
echo "Do you wish to create the cluster?"
select yn in "Yes" "No"; do
    case $yn in
        Yes )  "$mapreduceCodePath"/cluster.sh create smiling-theory-197620_map_reduce firstcluster us-west1-a; break;;  #make install; break;;
        No ) break;;
    esac
done
#<backet name> <new cluster name> <zone>>
#"$mapreduceCodePath"/cluster.sh create smiling-theory-197620_map_reduce firstcluster us-west1-a

read -p "*** Press any key to 1. copy the twits to the backet.  2. start the mapreduce job. 3. read results from DB."
for file in twitsDirectory/*.txt;
do
  echo $(basename "$file")
  cd ~
  echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"

  echo "copy to backet?"
  select yn in "Yes" "No"; do
    case $yn in
        Yes ) gsutil cp "$file"  gs://smiling-theory-197620_map_reduce/"$file" ; break;;
        No ) break;;
    esac
  done
  #echo "*** copy $file to backet..."
  #gsutil cp "$file"  gs://smiling-theory-197620_map_reduce/"$file"
  cd "$mapreduceCodePath"
  #echo $(pwd)
  read -p "*** Make sure the cluster instances were created (BigTable shuold also exsists),/nPress any key to start the job..."
  "$mapreduceCodePath"/cluster.sh start firstcluster gs://smiling-theory-197620_map_reduce/"$file" $(basename "$file") $(basename "$file")
  echo "file: $file"
  echo "Tables:"
  cbt ls
  cd ~/outputData
  echo "*** Reading results from DB:"
  python ~/readResults
done
  cd ~
  echo "show results:"
  python showResults 


